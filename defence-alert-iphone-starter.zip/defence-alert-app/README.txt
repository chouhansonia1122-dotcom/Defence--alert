DEFENCE ALERT — iPhone PWA starter

WHAT IS INCLUDED
- Responsive mobile-first dashboard
- Categories: J&K Security, Indian Army, World Military, Defence Tech, Events
- Search/filter UI, alert preference demo, public source links
- PWA manifest and service-worker starter
- No fabricated live headlines; live feed is intentionally empty until connected to trusted news feeds/API.

IMPORTANT LIMITATION
This bundle is a front-end prototype, not yet a live news service. It does not currently fetch breaking news, send push notifications, sync preferences, or create automatic daily briefings. Those require secure HTTPS hosting, a backend/news-feed integration, and push-notification setup. On iPhone, web push generally requires a supported iOS version and adding the hosted web app to the Home Screen.

IPHONE INSTALL (AFTER HTTPS HOSTING)
1. Host these files at an HTTPS URL.
2. Open that URL in Safari on iPhone.
3. Tap Share -> Add to Home Screen.
4. Open the Home Screen app. Push alerts still require backend integration and permission.

TRUSTED PUBLIC SOURCE STARTERS
- https://www.pib.gov.in/
- https://indianarmy.nic.in/
- https://www.mod.gov.in/
- https://www.jkpolice.gov.in/
- https://drdo.gov.in/
- https://www.reuters.com/world/india/
- https://news.google.com/

SAFETY
Use public, verified reporting only. Do not publish classified, sensitive operational, or unverified incident details as fact.
